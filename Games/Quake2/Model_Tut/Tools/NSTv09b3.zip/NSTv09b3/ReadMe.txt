Hello All,
	Better late than never huh? =]  For most of you this version of NST is a _huge_ leap from the previous (0.76) version.  I have a few million things that I need to finish with it, but at this point, I do not have much time in my days to put toward that.  However, I do not plan to leave it at this.  There is a whole lot more on the way...much of it regarding obvious holes in the UI, and the painting modes.  The mapping tools are extremely good, but I still see a few weeks worth of work in them.  Anyway, let me just spew a bunch of info, and leave it at that...Enjoy!
	NPherno

New items to Beta 3:

Complete rewrite and organization of the code
Much more stable, crashes should be fewer
Tool Bars are updated with dynamic placements, will not save from session to session though [being worked on]
New Intro songs and preferences [look into it, its self explainitory]
The Phong/enviro lighting effects should cause no problems
Rectangle tools is more stable and has a "save state" option
Retro Mapping

Things on the way:

exchanging maping between different sessions of NST [sounds odd, but VERY useful]
some light mesh tools [deleteing of polygons, edge turn, welding verts...]
a raytracer [with shadows even :)]
another lighting mode that resembles MAX's default lighting
possibly more things, but we'll see what can be stuffed into the bag, we always are open to suggestions.


Known bugs/cautions

Snapshot:
If you do not press 24bit color, everything will work fine.
If you do, you must press smooth and adjust the bar...otherwise it won't work...for now.
Also, the only mode that you should try to take a 24bit shot in is Textured+PhongMapped.
The max res for a "custom" shot is 20482048.

Benchmark:
This just tests the current mode's FPS.  It may look like it's hung for a sec...'cause I render a ton of frames.

Refresh:
If you load a model, and change it's skin size, then try to do the F5 refresh from disk, you will most likely crash...easy enough to fix, but I didn't get to it.

Mapping Mode/Paint Mode/Render Mode:
Here's a simple rule to follow, DO NOT TRY TO PAINT IF YOU CAN'T SEE THE SKIN.  I just know that a few hundred e-mails about that were pointed my way...I will set some code in place to disable painting in those situations, but for now, just don't do it.

SkinFX:
Some of this is broken, some is not...use at your own risk...I have much to do on this.

Well, I am sure there are a ton of other things I am forgetting, but I gotte get some work done today.

Here's some info on the feature set, and a general guide to the controls:

Space toggles camera mode...I know it may be confusing for some, and I will look for an alternate system, but for now, it's the way it is.

The mix bar in the middle has 3 buttons:
The first moves the bar, right click it to swap views. The other 2 store bar placement settings...left click to load the setting, right to set it.

As you know, the meter in the mix bar sets all kind of "mix" related things...however, right dragging it sets the lighting falloffs.

There are now 2 painting modes...mix (from 0.76) and tint (there ya go, enjoy Bone!).

The paper clip sets the "sticky" mode on...use this to have the skin follow the mapping when you move it in the 2d view.
The rectangle allows you to draw a rectangle that will be used for a number of things.  Right now it's just used for mapping from the 3d view...more is coming...good stuff too.

< and > move the colors by 1 and ; and ' move the colors by 16...just a quick one.

The 8 colors on the lower left are quick colors...not only can you select each and draw with it, but the color at each location stores a setting for other visual things...so the 8th color stores the background...the 2nd stores wireframes (unselected), the 3rd stores selected colors, and the 4th stores highlighted.

The 3rd and 4th can be set to any 2 colors, then the 5th and 6th can be set to 2 others...then under Skins->Replace Colors you can take any colors from the 3rd to the 4th and replace them with the 5th to the 6th...in that order...with gradients...it's a nice color replace...that I plan to make better soon.

Things I did not get done:

Flood Fill
Cut, Copy, Paste
Per-pixel selection masks
Masking
Variable sized brushes
Falloffs on those brushes
More 24bit snapshot modes
Faster rendering code

Okay...that's about it...post to the Q2pmp message board and I will try to reply...I am not including my e-mail address here for a reason...I am not ready to deal with a flood of help letters.  Have fun, and play nice!
	NPherno
