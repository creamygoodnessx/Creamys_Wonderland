Ryoko Izumo
Character made by Hiram Yagami.
Contact: Goenitz69@Hotmail.com.
Orizaba, Ver. Mexico
-----------------------------------------------------------------------

She is one of my favorite characters in WHP, it is for that reason that 
I made this small homage to that fabulous video game.

this character is taken out of the video game of World Heroes.

-----------------------------------------------------------------------
Styles:
-----------------------------------------------------------------------

The King of Fighters.
All World Heroes Series.
Neogeo Battle colliseum.
Fatal Fury Real Bout.
Fighters History.

-----------------------------------------------------------------------
Technical data:
-----------------------------------------------------------------------

Basics     = 100%
Specials   = 100% 
Hyper      = 100%
Throws     = 100%
Victorys   = 100%
Taunt      = 100%
Sprites    = 1040
Actions    = 399
Pals       = 14

-----------------------------------------------------------------------
Ryoko Profile:
-----------------------------------------------------------------------

Age:              16 
Birthday:         May, 12 1976 
Country:          Japan 
Height:           162 cm. 
Weight:           48 kg. 
Blood Type:       B. 
Three Sizes:      B81cm-W57cm-H83cm. 
Profession:       Judo Queen, High School Student. 
Fighting Style:   Izumo Ryu Kobojutsu. 
Hobby:            Perform throwing Techniques. 
Likes:            Matrimony, Sushi, Sweet cute boys. 
Dislikes:         English language, Airplanes, Her Father. 
Most Valuable:    Her Ribbon.

-----------------------------------------------------------------------
Ryoko Moves:
-----------------------------------------------------------------------

Bosatsusho 
Judo Kick 
Air Body Bounce 
Laria Drop 
Shin Bosatsusho 
Mugger Throw 

-----------------------------------------------------------------------
Other data:
-----------------------------------------------------------------------

Ryoko is based on Ryoko Tani 
She admires Janne and Hanzo, considering them her role models; Janne for
her beauty and strength, Hanzo for his skill. There also exists another 
female character called Ryoko Kano whose martial art is judo, in Data East's 
Fighter's History. She is also based on Ryoko Tani; the Kano surname is 
a possible tribute to Jigoro Kano, the founder of judo.

-----------------------------------------------------------------------
Special thanks:
-----------------------------------------------------------------------

.Bad Darkness   = for his open-source Izumo Ryoko 
.Juke kisaragi  = sounds, sprites and codes from his creations
.Warusaki3      = sprites and codes from his creations
."H�h"          = sprites and codes from his creations
.Dark Roken     = sprites and codes from his creations
."NHK"          = sprites from his creations
.JC Juan Carlos = for You Tutorial in Spanish
.Elecbite, for MUGEN 
.ADK, for World Heroes series
.Kawaks, Neogeo emulator
.SNK Playmore for all