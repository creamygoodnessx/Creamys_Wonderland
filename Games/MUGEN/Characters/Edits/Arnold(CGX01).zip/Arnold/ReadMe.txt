     _                     _     _ 
    / \   _ __ _ __   ___ | | __| |
   / _ \ | '__| '_ \ / _ \| |/ _` |
  / ___ \| |  | | | | (_) | | (_| |
 /_/   \_\_|  |_| |_|\___/|_|\__,_|
                                   
:==========================================:
:Arnold from Hey Arnold! by ToonAlexSora007:
:                                          :
:February 14, 2013                         :
:==========================================:

:========:
:Movelist:
:========:

========
Specials
========

Gum Throw
D, F, x

Tomato Throw
D, B, a

Flying Yo-Yo (Originally named ''Yo-Yo Fail'', due to not having idea what should the move be 
called :P)
D, B, z

Foot-ball Ball Throw
D, B, x/y/z

Camera Shot
F, B, a

Baseball Bat
D, B, x/y/z

Water Gun
D, B, a/b/c

Assist Gerald
F, D, B, c

Shoulder Assault
D, D, a/b/c

======
Hypers
======

Hyper Combo
D, DF, F, x+y

Bus Summon
D, B, a+c

Arnold Kart (Based on Nicktoons Racing :P)
D, B, x+y

Cyrnold (based on X-Men's Cyclops :P)
D, DF, F, D, DF, F, b

:============:
:Beta Testers:
:============:

LuketheMewtwo
TheWaluigiKing
TheIransonic
Zobbes
WlanmaniaX
RandomMaster007
Smeagol14
RoySquadRocks
Matydel42008
Dylanius9000
BeanFan112
Viniciuspikachu1

:=======:
:Credits:
:=======:

To Jarquin10, for making sprites for him :)

To WlanmaniaX, for making the Hyper Portrait, the Select Portrait and Win Portrait (Wich were fixed) 
and for getting some voice sounds for him :)

Alosson, for coding assistance.

Dylanius9000, for coding and sound assistance.

Craig Bartlett, for creating Arnold and this very good show :)

Marvel, for creating Cyclops and X-Men.

Elecbyte, for creating M.U.G.E.N.

==Spanish/Espa�ol===
:==========================================:
:Arnold de Oye Arnold! por ToonAlexSora007.:
:                                          :
:Febrero 14, 2013                          :
:==========================================:

:====================:
:Lista de Movimientos:
:====================:

==========
Especiales
==========

Embestida de Hombro
D, F, a/b/c

Lanzamiento de Goma
F, B, z

Lanzamiento de Tomate
F, B, x/y/z

Yo-Yo Volador (Originalmente llamado ''Falla de Yo-Yo'', debido a que no tenia idea de que nombre 
ponerle al movimiento :P)
F, B, a

Bat de Baseball
B, F, x/y/z

Arma de Agua
D,B,a/b/c

Asistente Gerald
D,B,c

Bola de Football
D, B, x/y/z

======
Hypers
======

Hiper Combo
D, DF, F, x+y

Autobus
D, B, a+c

Arnold Kart (Basado en Nicktoons Racing :P)
D, B, x+y

Cyrnold (Basado en Cyclops de X-Men :P)
D, DF, F, D, DF, F, b

:============:
:Beta Testers:
:============:

LuketheMewtwo
TheWaluigiKing
TheIransonic
Zobbes
WlanmaniaX
RandomMaster007
Smeagol14
RoySquadRocks
Matydel42008
Dylanius9000
BeanFan112
Viniciuspikachu1

:========:
:Creditos:
:========:

WlanmaniaX, por hacer la portada de hyper, la portada de seleccion, la portada de ganador 
(los cuales arregle) y por conseguirse algunos sonidos de voz para el :)

Jarquin10, por hacer sprites para el :)

Alosson, por assistencia de codificaci�n y sonido.

Dylanius9000, por assistencia de codificaci�n.

Craig Bartlett, por crear a Arnold y a esta muy buena serie :)

Marvel, por crear a Cyclops y a los X-Men.

Elecbyte, por crear M.U.G.E.N.
