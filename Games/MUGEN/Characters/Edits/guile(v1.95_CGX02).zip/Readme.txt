Guile EX: Version 1.95
----------------------
Mugen Version: 2001.04.14
Author: N64Mario (N64Mario84@hotmail.com)
Percent Complete = 98%
Released: 12/25/04
----------------------
SFA3 Guile: Hold start at character select screen.
SFA3 Mode has no new special/super moves and plays
almost like his SFA3 counterpart.

Whats in this version:
----------------------
6 Palettes
Required animations
All basic movement
All basic attacks
All basic close attacks
Grabbing
Air Grab
Combo System
Special Moves
Super Moves
1 Intros, 1 Taunt
Intro against Charlie
Intro against CvS Rugal
4 Win poses
Recovery Roll
Alpha Counter

Special Attacks:
----------------
Turn Punch - Hold F, HP
Knee Hop - Hold B or F, LK
Upside-Down Kick - Hold F, HK when close to opponent.
Forward Kick - Hold F, HK
Back Kick - Hold B, HK

Special Moves:
--------------
Power Charge - Hold LP + LK
Sonic Reflector - HP + HK
Sonic Boom - Hold B, F, P
Sonic Hurricane - Hold B, F, Start
Flash Kick - Hold D, U, K
Sonic Flash Kick - Hold B, F, K
Upside-Down Flash Kick - QCF, K (also done in air)
Fake Flash Kick Fall - Hold D, U, Start
Spinning Pile Driver = QCB, P
Tornado Kick - QCB, K

Alpha Counter:
-------------
Turn-punch - While Blocking, 2P

Super Moves:
------------
Sonic Fist - Hold B, F, 2P
	-> Sonic Strike - Must be close to opponent.
	-> Gigaton Punch - Must be far from opponent.
Final Mission - Hold B, F, 2K
Total Wipeout - QCFx2, P
Opening Gambit - QCBx2, P
Crossfire Blitz - QCFx2, K
Sonic Blade - Hold B, F, B, F, P
	     - Press P to throw more projectiles.
Charged Sonic Hurricane - Hold B, F, B, F, Start
			  - Hold Start to charge.
(*)Sonic Hurricane - Hold B, F, B, F, P
Somersault Strike - Hold DB, DF, DB, U, K
	Easy Move - QCBx2, K

[(*) = Only available in SFA3 Mode]

Contacts
--------
Fell free to send comments and suggestions to N64Mario84
(N64Mario84@hotmail.com). Thanks.
