Underdog.Beta 90% 1/17/2007
---------------------
Creater: Derrick Rowell (DDR) of Houston, Texas 

  M.U.G.E.N       (c) 2001 Elecbyte
                  www.elecbyte.com (deceased)

     I hope you gamers really enjoy my creations, because there are not a lot of good playable characters out there. I find myself being a great VS style player, so my creations are VS style. Sorry if its not your speed. Game developers out there, send me an email if you interested in my creative abilities. I'm an Design Engineer by trade designing things using 3d CAD software,but would like to express my ideas in a less structured environment than engineering requires. Thanks! 

This beta is only 97%. 



There are many moves to list, but I'll leave up to you to find them!

(Next update will list more of them.)
 Have fun!


    I'd like to add that with out the brilliant work of these creators, certain aspects of my characters would probably not be as refined:

    BB Hood's Push Blocking which is copied exactly and, the AI activation and guard modes are, I believe his. (http://a-and-f.mainpage.net)
   
    Splode. Well I'd like to say that it was Splodes Rouge which got my started developing for Mugen. In fact my first attempts at creating a character for Mugen used Rouge as a template. 
    There may be a few hints of similarities still hanging around in Popeye. Well thanks for provided such great work guys. 

    Well, thanks again BBHood!

Please guys, make sure no one uses my sprites without consent from me. It would really hurt my future releases.
Bug and ridiculous infinite reports please! Also, if you like my characters-- Donate--- on my site, thanks. Any motivation is much appreciated! 

email: telechy911@hotmail.com
http://telechy.sphosting.com/dada.htm 

