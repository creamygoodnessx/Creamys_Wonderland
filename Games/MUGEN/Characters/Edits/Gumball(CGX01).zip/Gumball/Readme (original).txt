Gumball Watterson by Cattigan619

Special Moves List:

Hadouken: D,DF,F, a
Charging Headbutt: D,DB,B, y
Darwin Assist: B,F, b
Clayzooka: D,DF,F, c
The Anaihilator: B,F, x

Super Move list:

Karate Barrage: D,DB,B,b+c
Rapid Paintball Shots: D,DF ,F, x+y
Hyper Hadouken: D,DF,F, a+b
Carrie Possession: D,DB,B,y+z

Credit to:
TheWaluigiKing for 2 palettes
Jenngra505 and PlasmoidThunder for testing and help
N64Mario for the HSFA Template
	