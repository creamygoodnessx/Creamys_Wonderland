---------Thank the people---------
Mugen Fighter(aka Ivan Luiz):do the Kinchi and Mung Daal Sprite
Wlanman:Collection of Chowder sound and do Midnight Bliss Sprite
MugenFAN(Raman Livingstone):Proposed Panini ideas
MUGENTOON(JNTHAN in deviantART):do Chowder and Schnitzel Spritesheet
-----------Commentary----------
Chowder is 10-year-old the Cat,Bear and Rabbit
Chowder is the apprentice chef for Mung Daal
and he has helped Mung prepare most meals for his Catering Company
like eat Food,girlfriend is Panini,but Chowder trying to evade her.
-----------Special-------------
spit out projectile:D,DF,F, x/y/z or D, DF, F, D, DF, F,z(700 Power)
Power Charge:Y+B
Grubble Gum:D,DF,F,a
Sharp fruit:D,DF,F,b
-----------helper--------------
Mung dall:D,DB,B,a
Shnitze:D,DB,B,b
Panini:D,DB,B,c
------------Hyper--------------
Froggy Apple Crumple Thumpkin(1000 Power):D, DF, F, x+y
Super pepper flame(2000 Power):D, DB, B, y+z
King of the Sky(3000 Power):D, DB, B, a+b
---------------------------------------------------------------------------------------------------
            Chowder

                      Chowder by Felixmario2011
                      2012/7/1~2012/7/3
(70%)
---------------------------------------------------------------------------------------------------