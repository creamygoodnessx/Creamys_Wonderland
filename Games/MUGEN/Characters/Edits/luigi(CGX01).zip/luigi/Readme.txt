Luigi - Super Smash Brothers
Game play based on SSB
----------------------
Mugen Version: WinMugen
Programed by N64Mario & TMasta  (N64Mario84@hotmail.com)
Sprites by Warner and some recoded.
Released: 10/9/05
----------------------
NOTE: The guard button doesn't seem to work well
	under DOS Mugen.  It is reccomended that
	you play this character in WinMugen. 


--------------
General Moves:
--------------
Run:			Forward x 2
Hop Back:		Back x 2
Fast Fall:		Down while in the air
Attack:			X
Shoot:			Y
Guard:			Z
Roll:			Hold Forward or Back while guarding
Taunt:			S (Start Button)


----------------
Special Attacks:
----------------
Grab:			Guard + Attack (Z + X)
 - Knee Attack:		X while holding opponent
 - Throw Forward:	Hold Forward while holding opponent
 - Giant Swing:		Hold Back while holding opponent
Standing Combo:		X, X, X
Head Smash:		Up + X
Smash Punch:		Forward + X
Standing Uppercut:	Hold Up + X
Standing Kick:		Hold Forward + X
Low Kick:		Hold Down + X
Sweep Kick:		Down + X
Jump Kick:		X while in the air
Flip Kick:		Hold Up + X while in the air
Drill Kick:		Hold Down + X while in the air
Smash Kick:		Forward + X while in the air
Ludicrous Punching:	X while running


--------------
Special Moves:
--------------
Note: All special moves can be done in the air.

Fireball:		Y
Fiery Punch:		Hold Up + Y			
Tornado Spin:		Hold Down + Y
			- Tap Y for extra jump boost

------------
Super Moves:
------------
Power Fireball:		X, X, Y
Falming Fiery Punch:	X, Up, Y
			- Press X upon a sucessful hit
			  to start Multi-Punch Rush.
			- Tap X during Punch Rush
			  for extra combo hits.
Spinning Tornado:	X, Down, Y


Contacts
--------
Fell free to send comments and suggestions to N64Mario84
(N64Mario84@hotmail.com). Thanks.
