Bubbles D.
Created by Kenshin Himura.
Date of Creation (wip): 16.11.2007
From Power PuffGirls Doujin (sprites by SemiJuggalo and I^^).
-----------------------------------------
Why I wanted to create her?
Re: I�ve got permission from SemiJuggalo who edited Bubbles from the Car Rangers characters and
I decided to create my own Bubbles.
-----------------------------------------
Hist�ria: Bubbles is one of the PPGs and she got moved to a new school and now strange
events will lead her and her sisters into a new battle.
-----------------------------------------
Release, 9 of december of 2007:
What she got?
a) All the basics.
b) Laser Eye (can be done in air and also while flying).
c) Sonic Boom.
d) Sonic Scream.
e) Power Dash (can be done in air and also while flying).
f) Power Charge
g) Fly (can attack while flying).
h) Mega Laser Eye.
i) Sonic Hurricane.
-----------------------------------------
Special Thanks:
-SemiJuggalo who gave permission for the usage of these sprites.
-Kaled^^ for helping with the sprite edits.
-Pgreed who gave permission for the usage of some sprites from Buttercup D.
And the Betatesters:
a) Wildee87.
b) Ryochi.
c) Delzepp.
d) Kaled^^.
e) PGreed.
f) Jaspion BR.
g) Axel Steel.
h) Rhysis.
i) XTHM.
k) Dr. Baldhead.
-----------------------------------------
Warning: This char is made for fans, not for sell.
-----------------------------------------