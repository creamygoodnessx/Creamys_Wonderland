Belmont Trusdale By kamekaze

ver .99

Story:
Belmont is about 24 years old. he is one year older than his brother Ed even though they look like twins. He and ed entered the army of the Shadaloo when Bison mislead them on
what he was doing. He then began to train them under. When he found out how Ed was increasing in strength faster than him, he agreed to be enhanced with the Psycho Power which 
increased his power tenfold and gave him abilities that he belived made him several times stronger than his brother, however he lost all of his good nature in the process, his 
eyes turned to a shade of red and he also gained murderous intent. His Brother escaped when he learned that Bison was trying to conquer the world while Belmont decided he should
stay to strike Bison down once he did. However Akuma interupeted his plans when he killed Bison with his Shun-Goku-Satsu. With the shadaloo destroyed he left and found him self 
in a city. He met Axel Stone and learned of Mr. X and his terror. He decided to fight along side Axel only if he was taught his bare knuckle. Axel agreed and they took down
Mr. X. He was regarded as a hero even though he didnt care to be, but before he defeated Mr. X he was told about Rugal and so he left to seek his teachings. Before leaving he 
was attacked by his brother. Edward tried to put up a good fight but was quickly defeated. Belmont told him don't follow him or he will kill him.

He arrived in the world of snk(it's like a new world to him but its only one planet)only to find Terry Bogard. He was told that Rugal was evil and not to be trusted. Belmont 
asked to be trained by him. Terry taught him his crack shoot, which Belmont quickly mastered. However Terry learned that Belmont had intentions of joing rugal and told him to
leave his sight at once. Belmont told him he would regret that and tried to fight him. Terry defeated him using his "Buster Wolf" and forced him to retreat.
 He finnaly met rugal and agreed to become one of his henchmen. Belmont wanted to learn all he can about rugal but unfortunetly Ed returned and tried to fight him again.
 Belmont defeated Ed oncemore and told him that he was stronger than last time. Rugal pittied Edward and trained him before Akuma interrupted again. Akuma was defeated and thus Rugal
 became God Rugal. Belmont saw his brother try to confront him. Belmont swiftly stoped G. Rugal from killing Ed(for reasons unknown) and faught G. Rugal. They fought for hours until
 Belmont caught him with his own form of Rugal's God End. After defeating Rugal he looked for his brother to finnally kill him. He found Ed and they fought. They were evenly matched
 until Ed caught Belmont with his Final Assault. Thus Belmont was defeated. Belmont swore his revenge and dissapeared. Belmont decided to train him self and enhance his own ability.

Now Belmont fights his brother evertime they meet to test his strength and doesn't think of it as rivalry. He considers his self the Stronger brother and wants cloak the world
in darkness.

controls
x= hook
y= gut punch
z= turn punch
a= knee breaker
b= rising knee
c= rising kick

throw = z upclose

flash step = F,D,DF , 2punches

roll back = B, 2 punches

anti air throw = 2 punches upclose (great for people who like to jump)

Kaiser slice = D,DF,F x or y or z

Crack Shoot = D,DB,B a or b or c

??? = D,F,DF a or b or c, once airborn press a or b to do  a diagnal kick. or press c for a special supprise(especially if the opponet isnt in the air)

Bare knuckle = F,F, x or y or z


Hypers:
Kaiser Pillar  = D,DF,F,D,DF,F, x(close) y(mid) or z(far) -1000 (can be linked from Death Dance)

Death Dance = D,DB,B,D,DB,B, x or y or z -1000

Crack Star = D,DB,B, 2 kicks -1000(great way to end air combos)

Kaiser End  = D,DF,F,D,DF,F, a, b, or c -3000 Belmonts version of God end

Saishu Kessen Ougi "Mu Shiki" = D,DB,B,D,DB,B, a, b or c -2000 Belmont's version of kyo's infamous move


Kamekaze Cancel system ver N/A
 not implemented

moves allowed so far:
none

notes:
1. his air version of his strong kick is a air-airluancher which will extend his air combo

special thx to:
kamek - for useage of some effects  (http://kamek.i-xxcell.com)
Liger - programming advice/help
laxx23 - for finding the game for me to rip sprites from
King Yoshi - for       pallettes 8-12
Red Navi- for use of effects
Fr33dom87 - for use of voices
