**********************************************************************

 Lilith                For M.U.G.E.N. (From Vampire Savior)

                            Ver. 0.8   (80% Complete !!)  2001/Aug./01
                                                  by M.M.R.
**********************************************************************

 Sorry, I'm not good at English so, it is poor at English.(^_^;)


++++++++++++++++++++
 UpDate ('01/08/01)
++++++++++++++++++++

 / Adds EX move, "Gloomy Puppet Show" !!

 / Adds her all sounds.

 / Adds moveing get up motion.

 / Adds Guard Cancel. (Only Shining Blade)

 / Adds Win pause , Taunt and so on.

--------------------
 What's Lack
--------------------
 / Advancing guard.

 / Down Attack when opponents are lying down.

 / Dark Forces. (Mimic Doll and Mirror Doll)
   (Is it possible ?? (?_?) )

 / CPU's AI moves.

+++++++++++
 First
+++++++++++
 This character is "Lilith" for M.U.G.E.N.
 Her original game is "Vampire Savior" by Capcom.

+++++++++++++++
 Installation
+++++++++++++++
 DownLoad 1 file named "Lilith.zip".
 The "Lilith.zip"  contains 12 files or folder shown below.
  Lilith.air		
  Lilith.cmd		
  Lilith-N.cns		
  Lilith-S.cns		
  Lilith-H.cns		
  Lilith.def		
  Lilith.sff		
  Lilith01.act		ReadMe_J.txt (In Japanese)
  Lilith02.act		ReadMe.txt (In English, this file)
  Skill (Folder)

 Unzip a file then, put these files into 1 folder named "Lilith".
 Then Put "Lilith" folder into your Mugen "charas" folder.

 Ex.)
   muk10414-----charas
              :    |____Lilith
              :    :       |____Lilith.air
              :    :       :
              :    :       :
              :    :       :

 Add this line in your "select.def" in "data" folder.

 Lilith, stages/******.def

 Replace ****** with your favorite background name.

 Ok, run your Mugen then the Lilith's face is added your character
 select screen. Let's enjoy !!!

++++++++++++++++
 Commands
++++++++++++++++
 Please show "Skill_E.htm" in the "Skill" folder.
 Button layout is below...

  X Y Z
 (l ; :) : Deffault Keys
  A B C
 (, . /) : Deffault Keys

 X...Light Punch  ,  Y...Mid  Punch  ,  Z...Hard Punch
 A...Light Kick   ,  B...Mid  Kick   ,  C...Hard Kick

++++++++++++++++++
 Featuers
++++++++++++++++++
 / Air recover or fall recover
   Press 2 or 3 Punch Buttons , when he can recover.

 / (Air) Chain combos.

++++++++++++++
 Version ?
++++++++++++++
 This version is Ver.0.5.

+++++++++++++++
 What's lack
+++++++++++++++
 / Advancing guard.

 / Down Attack when opponents are lying down.

 / Dark Forces. (Mimic Doll and Mirror Doll)
   (Is it possible ?? (?_?) )

++++++++++++++
 Caution !
++++++++++++++
 Please do not link directly to the files on our site &
 Please do not upload the files on our site, Thank you.

++++++++++++++++++
 Special Thanx
++++++++++++++++++
 o Many creators' character helped me in my work. Thanx.
 o Thanks "Adamskie" for giving the sounds of Lilith.
 o Thanks Elecbyte for making the great 2D Game Engine "M.U.G.E.N.".
 o Thanks Capcom for making the great 2D Game "Vampire Savior".
 o Thanks many people who report me bugs or test playing.


++++++++++++++++++
 WebSite & E-Mail
++++++++++++++++++
 WebSite:  http://projectm.mgbr.net/  (Thanks MugenBR !!)
           * This site is Link Free. The place for link is above address.
 E-Mail ;  m.m.r@anet.ne.jp


