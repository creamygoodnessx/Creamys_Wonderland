FIUNN 0.7c FOR M.U.G.E.N.!!!

I. About Fiunn Himself

1. Who's Fiunn?

This guy was in my mind in 10 years..... When I was younger, i've "edited" some books with illustrations to make a comics in them. I've also drawn other comics featuring Fiunn in some notebooks....... Too bad i don't have them, I'd like to show you how he'd looked in the past (i have a camera.....)

2. What does He like or something? (The biography)

Name            = Fiunn
Age             = 20 years old
Birthday        = 16 June (Can't really renember when i've drawn his first comics......)
Blood Type      = ???
Nationality     = Japaneese
Fighting Style  = Kung Fu? (Prodobally..... this char has KFM's KFP :) )
Hobbies         = ???
Specialty       = ???
Most Important  = His wife, Kung Fu Man, Mr.Amiga (and other friends from his doujins)
Most Unpleasant = Suave Dude, his old enemies from his old doujins, everyone who looks like Tiger Woods...
Likes           = ???
Dislikes        = ???
Favorite Food   = ???
Favorite Music  = ???
Best Sport      = Judo
Strenghtness	= ???
Weakness	= ???

3. Questions about that biography

Q: I can see you don't renember some of his facts......
A: Yup......

Q: BTW What's the name of Fiunn's wife?
A: There's a fun fact about it... In the comics, he was named "Fiulna", but when i though (in 2004, when i started mugenizing him) that the name's female, I've called him "Fiunn" and the old name was reserved to his wife.....

II. About Mugen Fiunn

1. Instalation

You are so n00b as you can't even do this?

Unpack everything in chars/mm_fiunn folder, even if there's another mm_dink folder.

Then add the following line somewhere in select.def

mm_fiunn,random,ORDER=1;

of course you can modify this if you want :)

2. Gameplay

6-button, CVS-Pro styled char. He has even his CVS2 Groove select. (You select it in his intro pose)

3. His moves

Legend:

A - LK			UB		UF
B - MK				U
C - HK			B	-	F
X - LP				D
Y - MP			DB		DF
Z - HP
APunch: LP, MP, or HP
AKick: LK, MK, or HK

Basics:

Jab (LP)

Strong (MP)

Fierce (HP)

Short (LK)

Forward (MK)

RoundHouse (HK)

Groove Basics:

Name of the technique (Command) (Grooves the technique's in)

SideStep (F,F) (CAP)
Run (F,F) (SNKX)
BackStep (B,B) (CAPSNKX)
Rolling (LP+LK in CAN, Dir+LP+LK in X) (CANX)
Dodge (LP+LK) (SX)
Counter Movement (Dir+LP+LK) (NX)
Counter Attack (MP+MK) (CASNX)
Power Charge (hold MP+MK) (SX)
"Brasil" Time (MP+MK) (AX)
Dodge Attack (Kick or Punch while dodging) (SX)
Parry (Forward when the enemy is about to hit you) (PX)
Just Defense (Guard when the enemy is about to hit you) (PX)

Specials (They can be EX'ed with HP or HK):

Kung Fu Palm (D, DF, F, APunch)
Kung Fu Gong (D, DB, B, APunch)
Kung Fu Upper (F, D, DF, APunch)
SpaceBall (Charge B,F, APunch)
BikeKick (Charge B,F, AKick)

Supers (Needs at least 1 power bar):

Tripple Kung Fu Palm (D,DF,F,D,DF,F,APunch)
Smack Kung Fu Upper (D,DB,B,D,DB,B,APunch)
Power Beam (F,DF,D,DB,B,F,APunch)

Hypers (Needs 3 power bars):

Splinter Goku Satsu (LP,LP,F,LK,HP)
Gendikamada (Nope, not that powerfull like austin's) (F,HP,MP,LP,F)
Topsy Turvy Hat (D,D,D,LP+MP+HP)

4. Graphics

He's a hi-res character. To use the potential of hi-res graphics, find those following parms in data/mugen.cfg and change to:

Width  = 640
Height = 480

DoubleRes = 4

III. The progress

He is 84% complete

Whats missing:
- His Wife, prodobally as a striker or a midnight bliss ;)
- Ending storyboard
- BugFixes
- Everything that i forgot to list...

IV. Credits

It was made by Most_mysterious (q3adam@wp.pl)
NOTE: If you e-mail me, use english. It's also okay to use polish, but nothing more.

Other thanks:

Because "The war cannot be beaten by a one man" (taken from Call of Duty), so I couldn't made the char all by myself. Thus below are the list of creators who helped me with this.

- Elecbyte(http://mugen.elecbyte.com/) = for m.u.g.e.n. itself, what are you looking at?
- Jasc software = For their Paint Shop Pro
- Winane, along with others (ANMC, Bagaliao, YongMing, Roque, [E], and .R.I.P. FlowaGirl) (http://winane.shinmugen.net/) = for their 3l1t3 Ai activation
- Messatsu and Valodim = ;)
- Ragnarok Nemo(http://ragnarok.happy-cat.org/) = For his mee, the best mugen character utility ever.
- N64Mario = That head-hunter bought more big heads for me! :D
- Erradicator+Xenozip+Blip = some fx
- IronMugen = BeCause "Sion is s�odka" =)
- The MUGEN community (whitout brasillians - Some Random Racist) = you know why
- Pneophen for his damage dampender used in UMMBCM.....
- Google (www.google.com) = The only way i could find the big duck pic :)

Other "Fucks":
- DeleteBR = as usual.........
